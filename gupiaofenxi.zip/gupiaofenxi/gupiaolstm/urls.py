from django.urls import path,re_path
from gupiaolstm.views import search,result,lstm

urlpatterns = [
    path(r'', search),
    path(r'result/', result),
    # path(r'([0-9]+)/$', lstm),
    re_path(r'[a-z]+([0-9]{6})', lstm),
]