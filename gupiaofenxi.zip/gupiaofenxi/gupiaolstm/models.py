from django.db import models

# Create your models here.
class Gupiao(models.Model):
    
    name = models.CharField(max_length=20)
    daima = models.CharField(max_length=20)



