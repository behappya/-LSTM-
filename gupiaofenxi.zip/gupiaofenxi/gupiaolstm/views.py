from django.shortcuts import render

from django.http import HttpResponse

from gupiaolstm.models import Gupiao

import akshare as ak
import pandas as pd
from sklearn.preprocessing import StandardScaler
import numpy as np
from keras.models import Sequential
from keras.layers import Dense,LSTM,Dropout
import datetime
from pyecharts import options as opts
from pyecharts.charts import Line



# Create your views here.


# import pandas as pd

# df1 = pd.read_csv('D:\python\python\乱七八糟的单子\股票分析\stock_zh_a_spot.csv')

# for i in range(3491,len(df1)):
#     df1.iloc[i]['名称']
#     Gupiao.objects.create(
#         name=df1.iloc[i]['名称'],
#         daima = df1.iloc[i]['代码'],
#     )



def search(request):


    return render(request, 'search.html')
    # return HttpResponse('1111.html')

def result(request):
    
    q = request.GET.get('search_info')
    post_list = Gupiao.objects.filter(name__contains=q)    
    return render(request, 'result.html', {'post_list': post_list})

def lstm(request,daima):


    stock_zh_a_spot_df = ak.stock_zh_a_hist(daima,start_date='20220401')
    df = pd.DataFrame(stock_zh_a_spot_df,columns = ['日期','收盘'])
    dataset = df['收盘'].values
    st = StandardScaler()
    dataset_st = st.fit_transform(X = dataset.reshape(-1,1))
    dataX,data_Y = [],[]
    for i in range(0,len(dataset_st)-2-1):
        temp = dataset_st[i:i+2]
        dataX.append(temp)
        data_Y.append(dataset_st[i+2])
    trainX = np.array(dataX)
    trainY = np.array(data_Y)
    # print(trainX)
    date1 = trainY[-2:]
    date1 = [date1.tolist()]

    model = Sequential()
    model.add(LSTM(128,return_sequences=True,input_shape=(trainX.shape[1],1)))
    model.add(Dropout(0.2))

    model.add(LSTM(128,return_sequences=True))
    model.add(Dropout(0.2))

    model.add(LSTM(128))
    model.add(Dropout(0.2))

    model.add(Dense(1))

    model.compile(optimizer='rmsprop',loss='mse')

    model.fit(trainX,trainY,epochs=20,batch_size=32)

    pred_st = model.predict(date1)
    pred_st = st.inverse_transform(pred_st)
    now = datetime.datetime.now()
    date_after = (now+datetime.timedelta(days=1)).strftime('%Y-%m-%d')
    df11 = pd.Series()
    df11['日期'] = date_after
    df11['收盘'] = pred_st[0][0]
    df = df.append(df11,ignore_index=True)

    riqi_list = df['日期'].to_list()
    zhi_list = df['收盘'].to_list()
    
    (
            Line(init_opts=opts.InitOpts(chart_id=4,bg_color='#ADD8E6'))
            .add_xaxis(riqi_list)
            .add_yaxis(series_name = '股价', y_axis = zhi_list,is_smooth=True)
            
            
            .set_global_opts(title_opts=opts.TitleOpts(title="LSTM股价预测"))
            .render('./templates/lstm.html')
            
        )




    
    return render(request, 'lstm.html')